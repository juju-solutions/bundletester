maintainer       "Charles Butler"
maintainer_email "charles.butler@ubuntu.com"
license          "GPL-3"
description      "JuJu Helpers"

version          "0.2"
name             "juju-helpers"
