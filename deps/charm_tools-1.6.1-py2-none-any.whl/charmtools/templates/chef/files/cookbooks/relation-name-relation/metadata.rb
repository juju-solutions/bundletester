maintainer       "$metadata.maintainer"
maintainer_email "$metadata.maintainer"
license          "GPL-3"
description      "$metadata.summary"

version          "0.1"
name             "relation-name-relation"
depends          "juju-helpers"
