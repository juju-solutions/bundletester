*pathspec*: Path Specification
==============================

*pathspec* is a utility library for pattern matching of file paths. So
far this only includes `gitignore`_ style pattern matching which itself
incorporates POSIX `glob`_ patterns.

.. _`gitignore`: http://git-scm.com/docs/gitignore
.. _`glob`: http://man7.org/linux/man-pages/man7/glob.7.html


Tutorial
--------

Say you have a "Projects" directory and you want to back it up, but only
certain files, and ignore others depending on certain conditions::

	>>> import pathspec
	>>> # The gitignore-style patterns for files to select, but we're including
	>>> # instead of ignoring.
	>>> spec = """
	...
	... # This is a comment because the line begins with a hash: "#"
	...
	... # Include several project directories (and all descendants) relative to
	... # the current directory. To reference a directory you must end with a
	... # slash: "/"
	... /project-a/
	... /project-b/
	... /project-c/
	...
	... # Patterns can be negated by prefixing with exclamation mark: "!"
	...
	... # Ignore temporary files beginning or ending with "~" and ending with
	... # ".swp".
	... !~*
	... !*~
	... !*.swp
	...
	... # These are python projects so ignore compiled python files from
	... # testing.
	... !*.pyc
	...
	... # Ignore the build directories but only directly under the project
	... # directories.
	... !/*/build/q
	...
	... """

We want to use the ``GitIgnorePattern`` class to compile our patterns, and the
``PathSpec`` to provide an iterface around them::

	>>> spec = pathspec.PathSpec.from_lines(pathspec.GitIgnorePattern, spec.splitlines())

That may be a mouthful but it allows for additional patterns to be implemented
in the future without them having to deal with anything but matching the paths
sent to them. ``GitIgnorePattern`` is the implementation of the actual pattern
which internally gets converted into a regular expression. ``PathSpec`` is a
simple wrapper around a list of compiled patterns.

To make things simpler, we can use the registered name for a pattern class
instead of always having to provide a reference to the class itself. The
``GitIgnorePattern`` class is registered as **gitignore**::

	>>> spec = pathspec.PathSpec.from_lines('gitignore', spec.splitlines())

If we wanted to manually compile the patterns we can just do the following::

	>>> patterns = map(pathspec.GitIgnorePattern, spec.splitlines())
	>>> spec = PathSpec(patterns)

``PathSpec.from_lines()`` is simply a simple class method to do just that.

If you want to load the patterns from file, you can pass the instance directly
as well::

	>>> with open('patterns.list', 'r') as fh:
	>>>     spec = pathspec.PathSpec.from_lines('gitignore', fh)

You can perform matching on a whole directory tree with::

	>>> matches = spec.match_tree('path/to/directory')

Or you can perform matching on a specific set of file paths with::

	>>> matches = spec.match_files(file_paths)



License
-------

*pathspec* is licensed under the `Mozilla Public License Version 2.0`_. See
`LICENSE`_ or the `FAQ`_ for more information.

In summary, you may use *pathspec* with any closed or open source project
without affecting the license of the larger work so long as you:

- give credit where credit is due,

- and release any custom changes made to *pathspec*.

.. _`Mozilla Public License Version 2.0`: http://www.mozilla.org/MPL/2.0
.. _`LICENSE`: LICENSE
.. _`FAQ`: http://www.mozilla.org/MPL/2.0/FAQ.html


Source
------

The source code for *pathspec* is available from the GitHub repo
`cpburnz/python-path-specification`_.

.. _`cpburnz/python-path-specification`: https://github.com/cpburnz/python-path-specification


Installation
------------

*pathspec* requires the following packages:

- `setuptools`_

*pathspec* can be installed from source with::

	python setup.py install

*pathspec* is also available for install through `PyPI`_::

	pip install pathspec

.. _`setuptools`: https://pypi.python.org/pypi/setuptools
.. _`PyPI`: http://pypi.python.org/pypi/pathspec


.. image:: https://d2weczhvl823v0.cloudfront.net/cpburnz/python-path-specification/trend.png
   :alt: Bitdeli badge
   :target: https://bitdeli.com/free

Change History
==============


0.3.4 (2015-08-24)
------------------

- Issue #7: Fixed non-recursive links.
- Issue #8: Fixed edge cases in gitignore patterns.
- Issue #9: Fixed minor usage documentation.
- Fixed recursion detection.
- Fixed trivial incompatibility with Python 3.2.


0.3.3 (2014-11-21)
------------------

- Improved documentation.


0.3.2 (2014-11-08)
------------------

- Improved documentation.
- Issue #6: Fixed matching Windows paths.
- API change: `spec.match_tree` and `spec.match_files` now return iterators instead of sets


0.3.1 (2014-09-17)
------------------

- Updated README.


0.3.0 (2014-09-17)
------------------

- Added registered patterns.
- Issue #3: Fixed trailing slash in gitignore patterns.
- Issue #4: Fixed test for trailing slash in gitignore patterns.


0.2.2 (2013-12-17)
------------------

- Fixed setup.py


0.2.1 (2013-12-17)
------------------

- Added tests.
- Fixed comment gitignore patterns.
- Fixed relative path gitignore patterns.


0.2.0 (2013-12-07)
------------------

- Initial release.

