ruamel.base

- (future) place for elements common to multiple packages


