A collection of Python dictionary types that support attribute-style access.
Includes *defaultdict*,  *OrderedDict*, restricted, *ChainMap*, *Counter*, and
frozen implementations plus miscellaneous utilities for writing Python software.

